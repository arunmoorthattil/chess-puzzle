<?php
$global wpdb;
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $date = current_datetime();
     $points = $_POST['points'];
     
  $wpdb->query("INSERT INTO  $wpdb->A_PUZZLE_REPORT
                ( name, date, points )
                VALUES ( $name, $date, $points )"
            );
}
?>
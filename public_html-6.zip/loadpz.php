<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$sql = "SELECT * FROM wp_puzzles ORDER BY RAND() LIMIT 100";
$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>
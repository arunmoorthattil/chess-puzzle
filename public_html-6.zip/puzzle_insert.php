<html lang="en">
    <head>
        <title>Insert Puzzles</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta
          name="description"           
          content="A Simple Chess Puzzles.">
<script>
function submit()
{
<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
if(isset($_POST['submit']))
{    $fen = $_POST['fen'];
     $moves = $_POST['moves'];
     $table_name = wp_puzzles;  
}
Echo $id; 
Echo $points;
Echo $table_name;
$wpdb->insert(
            $table_name, 
			array(
			'fen' => $fen ,
             'moves'=>$moves),array( '%s','%s'));
?>			 
}
</script>
</head>
<body>
<link href = "https://www.learnmyskills.com/css/main.css" type = "text/css" rel = "stylesheet" />    
  <form onsubmit="submit()" method="post" enctype = "multipart/form-data" >
  <div class = "container">    
                        <div class="form-group">
						<label>FEN:</label>  
                            <input type="text" id="fen" name="fen"  size="250"class="form-control" >
                        </div>
                        <div class="form-group">
						<label>Moves separated by ,</label> 
                        <input type="text" id="moves" name="moves" size="250" class="form-control" >
                        </div>
                        <input type="submit" class="btn btn-primary" name="submit" value="Submit">
</form>
</body>
</html>

<?php require __DIR__ . '/wp-load.php';
global $wpdb;

if(isset($_POST['submit']))
{    $id = $_POST['name'];
     $points = $_POST['final'];
     $table_name = wp_puzzlereport;  
	 
	 Echo "submitted " ;
	 Echo $id ;
	 Echo  "Points " ;
	 Echo $points ;
	 $wpdb->insert(
            $table_name, 
			array(
			'username' => $id,
     	   'points' => $points),array( '%s','%d'));
}
?>	
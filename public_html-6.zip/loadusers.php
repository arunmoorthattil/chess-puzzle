<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$user= $_POST['key'];
$sql = "SELECT user_login FROM wp_users where user_login='$user'";
$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>
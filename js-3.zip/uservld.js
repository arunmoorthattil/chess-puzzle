function validateUser(user) {
	{
                $.post("loadusers.php",{key: user},
                function (data)
                {
         		var jdata=JSON.parse(data);
				if(jdata.length>0){
				console.log(jdata);
				 if(jdata[0].user_login===user){
				 document.getElementById("start").disabled = false;
				 const name =  document.getElementById('name');
                // setting the value
                  name.value = user;
				  removeDummy();
				  $('#usermsg').html("Welcome, "+user) ;
				  $('#status').html("");
				 } 				 
				 } else{
				$('#status').html("Not a Valid user, Try again or Register to Continue.") ;
				 }	
}
				
  	);
   }
}


function removeDummy() {
    var elem = document.getElementById('uname');
    elem.parentNode.removeChild(elem);
	var elem = document.getElementById('usubmit');
    elem.parentNode.removeChild(elem);
 }